import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demande-formation',
  templateUrl: './demande-formation.component.html',
  styleUrls: ['./demande-formation.component.css']
})
export class DemandeFormationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
